/**
 * 
 */
package org.demo.omdb.api.main;

import org.demo.omdb.api.constant.Constants;
import org.demo.omdb.api.interfaces.OMDbService;
import org.demo.omdb.api.interfaces.impl.OMDbServiceImpl;

/**
 * Application for retrieving all movie details using title or imdbi id keywords
 * using OMDB API. Currently application is trying to retrieve only the movie
 * details but in future we can integrate a music API also
 * 
 * @author Sebin Joseph
 *
 */
public class OMDbServiceClient {

	/**
	 * Main method calling service impl methods by movie title or imdb id.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		callOMDbAPIForMovies();
	}

	/**
	 * Method which calls various method in service implementation class for
	 * searching movie with title and id
	 * 
	 * First condition checks, if -Dapi=omdb and -Dmovietitle=Batman then call
	 * searchMovieByTitle.
	 * For eg: java -jar -Dapi=omdb -Dmovietitle=batman build\libs\omdbdemo-all-1.0.jar
	 * 
	 * Second condition checks, if -Dapi=omdb and -Dimdbid=tt0097576 then call
	 * searchMovieByImdb
	 * For eg: java -jar -Dapi=omdb -Dimdbid=tt0097576 build\libs\omdbdemo-all-1.0.jar
	 */
	private static void callOMDbAPIForMovies() {
		OMDbService oMDbService = new OMDbServiceImpl();
		if (System.getProperty(Constants.API_KEY_NAME) != null
				&& System.getProperty(Constants.API_KEY_NAME).equalsIgnoreCase(Constants.API_KEY_VALUE)
				&& System.getProperty(Constants.MOVIE_TITLE_KEY) != null) {
			String movieTitle = System.getProperty(Constants.MOVIE_TITLE_KEY);
			oMDbService.searchMovieByTitle(movieTitle, Constants.API_SECRET_KEY);
		} else if (System.getProperty(Constants.API_KEY_NAME) != null
				&& System.getProperty(Constants.API_KEY_NAME).equalsIgnoreCase(Constants.API_KEY_VALUE)
				&& System.getProperty(Constants.IMDB_ID_KEY) != null) {
			String imdb = System.getProperty(Constants.IMDB_ID_KEY);
			oMDbService.searchMovieByImdb(imdb, Constants.API_SECRET_KEY);
		} else {
			System.out.println("Invalid system properties!");
		}
	}
}
