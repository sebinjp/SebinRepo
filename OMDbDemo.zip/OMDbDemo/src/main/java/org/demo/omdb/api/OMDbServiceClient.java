/**
 * 
 */
package org.demo.omdb.api;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Application for retrieving all movie details using title or imdbi id keywords
 * using OMDB API. Currently application is trying to retrieve only the movie
 * details but in future we can integrate a music API also
 * 
 * @author Sebin Joseph
 *
 */
public class OMDbServiceClient {

	/**
	 * API_KEY_VALUE
	 */
	private static final String API_KEY_VALUE = "5f9f2483";

	/**
	 * SEARCH_URL
	 */
	private static final String SEARCH_URL = "http://www.omdbapi.com/?s=TITLE&apikey=APIKEY";

	/**
	 * SEARCH_BY_IMDB_URL
	 */
	private static final String SEARCH_BY_IMDB_URL = "http://www.omdbapi.com/?i=IMDB&apikey=APIKEY";

	/**
	 * MOVIE_TITLE_KEY
	 */
	private static final String MOVIE_TITLE_KEY = "movietitle";

	/**
	 * API_KEY_NAME
	 */
	private static final String API_KEY_NAME = "api";

	/**
	 * MOVIE_ID_KEY
	 */
	private static final String IMDB_ID_KEY = "imdbid";

	/**
	 * httpClient
	 */
	private static final HttpClient httpClient;

	static {
		httpClient = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(10))
				.build();
	}

	/**
	 * Main method calling methods by movie title or imdb id.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (System.getProperty(API_KEY_NAME) != null && System.getProperty(API_KEY_NAME).equalsIgnoreCase("omdb")
				&& System.getProperty(MOVIE_TITLE_KEY) != null) {
			String movieTitle = System.getProperty(MOVIE_TITLE_KEY);
			OMDbServiceClient.searchMovieByTitle(movieTitle, API_KEY_VALUE);
		} else if (System.getProperty(API_KEY_NAME) != null && System.getProperty(API_KEY_NAME).equalsIgnoreCase("omdb")
				&& System.getProperty(IMDB_ID_KEY) != null) {
			String imdb = System.getProperty(IMDB_ID_KEY);
			OMDbServiceClient.searchMovieByImdb(imdb, API_KEY_VALUE);
		} else {
			System.out.println("Invalid systemproperties!");
		}
	}

	/**
	 * Method which search and print all movies with a movie title It returns a Json
	 * array and we retrieve all those array values to print in a console while
	 * executing the jar
	 * 
	 * @param requestUrl
	 */
	private static void sendMovieTitleGetRequest(String requestUrl) {
		HttpRequest request = createHttpRequest(requestUrl);

		HttpResponse<String> response = null;
		response = httpClientRequestSend(request, response);
		if (response != null) {
			JSONObject jsonObj = new JSONObject(response.body());
			if (jsonObj.getString("Response").equalsIgnoreCase("True")) {
				JSONArray jsonData = jsonObj.getJSONArray("Search");
				int length = jsonObj.length();
				for (int i = 0; i < length; i++) {
					JSONObject jObj = jsonData.getJSONObject(i);
					System.out.println(i + ".\t | Title: " + jObj.getString("Title") + "\t | Year: " + jObj.getString("Year")
							+ "\t | imdbID: " + jObj.getString("imdbID") + "\t | Type: " + jObj.getString("Type"));
					System.out.println(
							"----------------------------------------------------------------------------------------------------------------------------------");
				}
			} else {
				System.out.println(response.body());
			}
		}
	}

	/**
	 * @param requestUrl
	 * @return
	 */
	private static HttpRequest createHttpRequest(String requestUrl) {
		return HttpRequest.newBuilder().GET().uri(URI.create(requestUrl))
				.setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
				.build();
	}

	/**
	 * Method which search and print all movies with a movie imdb id.
	 * 
	 * @param requestUrl
	 */
	private static void sendMovieImdbIdGetRequest(String requestUrl) {
		HttpRequest request = createHttpRequest(requestUrl);

		HttpResponse<String> response = null;
		response = httpClientRequestSend(request, response);
		if (response != null) {
			JSONObject jsonObj = new JSONObject(response.body());
			if (jsonObj.getString("Response").equalsIgnoreCase("True")) {
				System.out.println("Title: " + jsonObj.getString("Title") + "\t | Released: "
						+ jsonObj.getString("Released") + "\t | Year: " + jsonObj.getString("Year") + "\t | Director: "
						+ jsonObj.getString("Director") + "\t | Actors: " + jsonObj.getString("Actors"));
			} else {
				System.out.println(response.body());
			}
		}
	}

	/**
	 * @param request
	 * @param response
	 * @return HttpResponse<String>
	 */
	private static HttpResponse<String> httpClientRequestSend(HttpRequest request, HttpResponse<String> response) {
		try {
			if (request != null && httpClient != null) {
				response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			}
		} catch (IOException | InterruptedException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * @param title
	 * @param key
	 */
	private static void searchMovieByTitle(String title, String key) {
		try {
			title = URLEncoder.encode(title, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		String requestUrl = SEARCH_URL.replace("TITLE", title).replace("APIKEY", key);
		sendMovieTitleGetRequest(requestUrl);
	}

	/**
	 * @param imdb
	 * @param key
	 */
	public static void searchMovieByImdb(String imdb, String key) {
		String requestUrl = SEARCH_BY_IMDB_URL.replace("IMDB", imdb).replace("APIKEY", key);
		sendMovieImdbIdGetRequest(requestUrl);
	}
}
