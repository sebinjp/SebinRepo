/**
 * 
 */
package org.demo.omdb.api.interfaces.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import org.demo.omdb.api.constant.Constants;
import org.demo.omdb.api.interfaces.OMDbService;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Service interface implementation class for the omdb demo application.
 *  
 * @author Sebin Joseph
 *
 */
public class OMDbServiceImpl implements OMDbService {

	/**
	 * httpClient
	 */
	private static final HttpClient httpClient;

	static {
		httpClient = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1).connectTimeout(Duration.ofSeconds(10))
				.build();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#sendMovieTitleGetRequest(java.lang.
	 * String)
	 * 
	 * 
	 * Method which search and print all movies with a movie title It returns a Json
	 * array and we retrieve all those array values to print in a console while
	 * executing the jar
	 * 
	 * @param requestUrl
	 *
	 */
	@Override
	public void sendMovieTitleGetRequest(String requestUrl) {
		HttpRequest request = createHttpRequest(requestUrl);

		HttpResponse<String> response = null;
		response = httpClientRequestSend(request, response);
		if (response != null) {
			JSONObject jsonObj = new JSONObject(response.body());
			if (jsonObj.getString("Response").equalsIgnoreCase("True")) {
				JSONArray jsonData = jsonObj.getJSONArray("Search");
				int length = jsonObj.length();
				for (int i = 0; i < length; i++) {
					JSONObject jObj = jsonData.getJSONObject(i);
					System.out.println(i + ".\t | Title: " + jObj.getString("Title") + "\t | Year: "
							+ jObj.getString("Year") + "\t | imdbID: " + jObj.getString("imdbID") + "\t | Type: "
							+ jObj.getString("Type"));
					System.out.println(
							"----------------------------------------------------------------------------------------------------------------------");
				}
			} else {
				System.out.println(response.body());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#createHttpRequest(java.lang.String)
	 * 
	 * Creating HttpRequest instance which is communicating with URI.
	 */
	@Override
	public HttpRequest createHttpRequest(String requestUrl) {
		return HttpRequest.newBuilder().GET().uri(URI.create(requestUrl))
				.setHeader("User-Agent", "Java 11 HttpClient Bot") // add request header
				.build();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#searchMovieByTitle(java.lang.String,
	 * java.lang.String)
	 * 
	 * Searching for movie with title and OMDB API key.
	 */
	@Override
	public void searchMovieByTitle(String title, String key) {
		try {
			title = URLEncoder.encode(title, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		String requestUrl = Constants.SEARCH_BY_TITLE_URL.replace("TITLE", title).replace("APIKEY", key);
		sendMovieTitleGetRequest(requestUrl);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#sendMovieImdbIdGetRequest(java.lang.
	 * String)
	 * 
	 * Method which search and print all movies with a movie imdb id.
	 */
	@Override
	public void sendMovieImdbIdGetRequest(String requestUrl) {
		HttpRequest request = createHttpRequest(requestUrl);

		HttpResponse<String> response = null;
		response = httpClientRequestSend(request, response);
		if (response != null) {
			JSONObject jsonObj = new JSONObject(response.body());
			if (jsonObj.getString("Response").equalsIgnoreCase("True")) {
				System.out.println("Title: " + jsonObj.getString("Title") + "\t | Released: "
						+ jsonObj.getString("Released") + "\t | Year: " + jsonObj.getString("Year") + "\t | Director: "
						+ jsonObj.getString("Director") + "\t | Actors: " + jsonObj.getString("Actors"));
			} else {
				System.out.println(response.body());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#httpClientRequestSend(java.net.http.
	 * HttpRequest, java.net.http.HttpResponse)
	 * 
	 * Creating HttpResponse which contains response from specified URI.
	 */
	@Override
	public HttpResponse<String> httpClientRequestSend(HttpRequest request, HttpResponse<String> response) {
		try {
			if (request != null && httpClient != null) {
				response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
			}
		} catch (IOException | InterruptedException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.demo.omdb.api.interfaces.OMDbService#searchMovieByImdb(java.lang.String,
	 * java.lang.String)
	 * 
	 * Searching for movie with imdb id and OMDB API key.
	 */
	@Override
	public void searchMovieByImdb(String imdb, String key) {
		String requestUrl = Constants.SEARCH_BY_IMDB_URL.replace("IMDB", imdb).replace("APIKEY", key);
		sendMovieImdbIdGetRequest(requestUrl);
	}

}
