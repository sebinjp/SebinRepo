package org.demo.omdb.api.constant;

/**
 * Constant class for OMDb API call application
 * 
 * @author Sebin Joseph
 *
 */
public class Constants {

	private Constants() {

	}

	/**
	 * API_KEY_VALUE
	 */
	public static final String API_SECRET_KEY = "5f9f2483";

	/**
	 * SEARCH_URL
	 */
	public static final String SEARCH_BY_TITLE_URL = "http://www.omdbapi.com/?s=TITLE&apikey=APIKEY";

	/**
	 * SEARCH_BY_IMDB_URL
	 */
	public static final String SEARCH_BY_IMDB_URL = "http://www.omdbapi.com/?i=IMDB&apikey=APIKEY";

	/**
	 * MOVIE_TITLE_KEY
	 */
	public static final String MOVIE_TITLE_KEY = "movietitle";

	/**
	 * API_KEY_NAME
	 */
	public static final String API_KEY_NAME = "api";
	
	/**
	 * API_KEY_VALUE
	 */
	public static final String API_KEY_VALUE = "omdb";

	/**
	 * MOVIE_ID_KEY
	 */
	public static final String IMDB_ID_KEY = "imdbid";

}
