/**
 * 
 */
package org.demo.omdb.api.interfaces;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Interface for OMDb service.
 * 
 * @author Sebin Joseph
 *
 */
public interface OMDbService {

	/**
	 * @param requestUrl
	 */
	public void sendMovieTitleGetRequest(String requestUrl);

	/**
	 * @param requestUrl
	 * @return HttpRequest
	 */
	public HttpRequest createHttpRequest(String requestUrl);

	/**
	 * @param title
	 * @param key
	 */
	public void searchMovieByTitle(String title, String key);

	/**
	 * @param requestUrl
	 */
	public void sendMovieImdbIdGetRequest(String requestUrl);

	/**
	 * @param request
	 * @param response
	 * @return HttpResponse
	 */
	public HttpResponse<String> httpClientRequestSend(HttpRequest request, HttpResponse<String> response);

	/**
	 * @param imdb
	 * @param key
	 */
	public void searchMovieByImdb(String imdb, String key);
}
